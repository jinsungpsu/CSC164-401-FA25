module com.example.csc164week13 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.csc164week13 to javafx.fxml;
    exports com.example.csc164week13;
}